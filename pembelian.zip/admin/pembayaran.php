<h2>Data Pembayaran</h2>

<?php  
// Validasi parameter ID
if (!isset($_GET['id'])) {
    die("ID pembelian tidak ditemukan.");
}

$id_pembelian = $_GET['id'];

// Periksa koneksi database
$koneksi =  mysqli_connect('localhost', 'root', '', 'skin_beauty_care') ;
if ($koneksi->connect_error) {
    die("Koneksi database gagal: " . $koneksi->connect_error);
}

// Mengambil data pembayaran berdasarkan ID pembelian
$stmt = $koneksi->prepare("SELECT * FROM pembayaran WHERE id_pembelian = ?");
$stmt->bind_param("i", $id_pembelian);
$stmt->execute();
$result = $stmt->get_result();
$detail = $result->fetch_assoc();
$stmt->close();

if (!$detail) {
    die("Data pembayaran tidak ditemukan untuk ID pembelian ini.");
}

// Debug data pembayaran
//echo "<pre>";
//print_r($detail);
//echo "</pre>";

// Validasi file bukti pembayaran
$file_path = "../bukti_pembayaran/" . $detail['bukti'];
if (!file_exists($file_path)) {
    die("File bukti pembayaran tidak ditemukan.");
}
?>

<div class="row">
    <div class="col-md-6">
        <table class="table">
            <tr>
                <th>Nama</th>
                <td><?php echo $detail['nama'] ?></td>
            </tr>
            <tr>
                <th>Bank</th>
                <td><?php echo $detail['bank'] ?></td>
            </tr> 
            <tr>
                <th>Jumlah</th>
                <td>Rp. <?php echo number_format($detail['jumlah']) ?></td>
            </tr>
            <tr>
                <th>Tanggal</th>
                <td><?php echo $detail['tanggal'] ?></td>
            </tr>
        </table>
    </div>
    <div class="col-md-6">
        <img src="<?php echo $file_path ?>" alt="" class="img-responsive">
    </div>
</div>


<form method="post">
    <div class="form-group">
        <label>No Resi Pengiriman</label>
        <input type="text" class="form-control" name="resi">
    </div>
    <div class="form-group">
        <label>Status</label>
        <select class="form-control" name="status">
            <option value="">Pilih Status</option>
            <option value="lunas">Lunas</option>
            <option value="barang dikirim">Barang Dikirim</option>
            <option value="batal">Batal</option>
        </select>
    </div>
    <button class="btn btn-primary" name="proses">Proses</button>
</form>

<?php  
if (isset($_POST["proses"])) 
{
    $resi = $_POST["resi"];
    $status = $_POST["status"];
    $koneksi->query("UPDATE pembelian SET resi_pengiriman='$resi', status_pembelian='$status' WHERE id_pembelian='$id_pembelian'");

    echo "<script>alert('Data Pembelian Terupdate');</script>";
    echo "<script>location='index.php?halaman=pembelian';</script>";
}
?>