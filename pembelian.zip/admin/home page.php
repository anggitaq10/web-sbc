<h2>Welcome Admin</h2>
<pre><?php print_r($_SESSION); ?> </pre> 
	