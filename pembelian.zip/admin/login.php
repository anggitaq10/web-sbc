<?php  
session_start();
$koneksi = new mysqli("localhost", "root", "", "skin_beauty_care")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body{padding-top: 20px;}
    </style>
</head>
<body>
    <div class="container">
        <div class="col-md-4 col-md-push-4">
            <form method="post">
                <div class="form-group">
                    <label for="Username">Username</label>
                    <input type="text" class="form-control" name="username" placeholder="Username">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Password">
                </div>
                <button type="submit" name="login" class="btn btn-default">Login</button>
            </form>
            <?php  
            if (isset($_POST['login'])) 
            {
                $ambil = $koneksi->query("SELECT * FROM admin_toko WHERE username = '$_POST[username]' AND password = '$_POST[password]'");
                $yangcocok = $ambil->num_rows;
                if ($yangcocok==1) 
                {
                    $_SESSION['admin']=$ambil->fetch_assoc();
                    echo "<div class = 'alert alert-info'>Login Sukses</div>";
                    echo "<meta http-equiv = 'refresh' content = '1;url=index.php'>";
                }
                else
                {
                    echo "<div class = 'alert alert-danger'>Login Gagal</div>";
                    echo "<meta http-equiv = 'refresh' content = '1;url=login.php'>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
